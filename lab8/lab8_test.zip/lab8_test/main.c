/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"

#define DELAY (16000000)
int t = 0;
int del_div = 1;
volatile bool gCheckADC;
volatile uint16_t gAdcResult;
volatile int16_t gADCOffset;

void check_val(){
    DL_ADC12_startConversion(ADC12_0_INST);

    while (false == gCheckADC) {
        __WFE();
    }

    gAdcResult = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);

    /* Apply calibrated ADC offset - workaround for ADC_ERR_06 */
    int16_t adcRaw = (int16_t) gAdcResult + gADCOffset;
    if (adcRaw < 0) {
        adcRaw = 0;
    }
    if (adcRaw > 4095) {
        adcRaw = 4095;
    }
    gAdcResult = (uint16_t) adcRaw;

    gAdcResult = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
    if (gAdcResult>1000) {
        DL_SYSCTL_enableBeeperOutput();
    }else{
        DL_SYSCTL_disableBeeperOutput();

    }

    del_div=((30*gAdcResult)/1011);
    gCheckADC = false;
    DL_ADC12_enableConversions(ADC12_0_INST);
}

int main(void)
{
    SYSCFG_DL_init();

    gADCOffset =
        DL_ADC12_getADCOffsetCalibration(ADC12_0_ADCMEM_0_REF_VOLTAGE_V);


    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
    gCheckADC = false;
    DL_ADC12_enableConversions(ADC12_0_INST);

    /* Power on GPIO, initialize pins as digital outputs */
    SYSCFG_DL_init();

    /* Default: LED1 and LED3 ON, LED2 OFF */
    DL_GPIO_setPins(GPIO_LEDS_PORT, GPIO_LEDS_LED_0_PIN);
    DL_GPIO_setPins(GPIO_LEDS_PORT, GPIO_LEDS_LED_1_PIN);
    DL_GPIO_setPins(GPIO_LEDS_PORT, GPIO_LEDS_LED_2_PIN);


    while (1) {
        /*
         * Call togglePins API to flip the current value of LEDs 1-3. This
         * API causes the corresponding HW bits to be flipped by the GPIO HW
         * without need for additional R-M-W cycles by the processor.
         */
        check_val();
        if (del_div <1 ){
            del_div=1;
        }
//        if (t == 0){
//            DL_GPIO_togglePins(
//                GPIO_LEDS_PORT, GPIO_LEDS_LED_0_PIN);
//            delay_cycles(DELAY/del_div);
//            DL_GPIO_togglePins(
//                GPIO_LEDS_PORT, GPIO_LEDS_LED_0_PIN);
//        }
//        if (t == 1){
//            DL_GPIO_togglePins(
//                GPIO_LEDS_PORT, GPIO_LEDS_LED_1_PIN);
//            delay_cycles(DELAY/del_div);
//            DL_GPIO_togglePins(
//                GPIO_LEDS_PORT, GPIO_LEDS_LED_1_PIN);
//        }
//        if (t == 2){
//            DL_GPIO_togglePins(
//                GPIO_LEDS_PORT, GPIO_LEDS_LED_2_PIN);
//            delay_cycles(DELAY/del_div);
//            DL_GPIO_togglePins(
//                GPIO_LEDS_PORT, GPIO_LEDS_LED_2_PIN);
//        }
        t++;
        if (t>=3)
            t = 0;

        DL_GPIO_clearPins(
            GPIO_LEDS_PORT, GPIO_LEDS_LED_0_PIN );
        delay_cycles(DELAY/del_div);
        DL_GPIO_setPins(
            GPIO_LEDS_PORT, GPIO_LEDS_LED_0_PIN | GPIO_LEDS_LED_1_PIN | GPIO_LEDS_LED_2_PIN);
        delay_cycles(DELAY);



    }

}

void ADC12_0_INST_IRQHandler(void)
{
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            gCheckADC = true;
            break;
        default:
            break;
    }
}
