/*
 * This template file
 */

#include <lab3_helper.h>
#include <ti/devices/msp/msp.h>
#include <string.h>


/* This results in approximately 0.5s of delay assuming 32.768 kHz CPU_CLK */
#define DELAY (3276) // N+1 is period

// Define spacing constants for different elements in the message
#define LINE_GAP 7  // Gap between sentences or major breaks
#define WORD_GAP 3  // Gap between words
#define CHAR_GAP 1  // Gap between characters

// Define a default message if MESSAGE is not provided at compile time
#ifndef MESSAGE
    char message[] = "... --- ...;";  // Default message (SOS in Morse code)
#else
    char message[] = MESSAGE;
#endif

// Blue LED
#define PIN  (0x1u << 22)

void InitializeGPIO(void) {
    GPIOB->GPRCM.RSTCTL = (GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETSTKYCLR_CLR | GPIO_RSTCTL_RESETASSERT_ASSERT);
    GPIOB->GPRCM.PWREN = (GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE);

    delay_cycles(POWER_STARTUP_DELAY); // delay to enable GPIO to turn on and reset

    /* - TODO! - */
    // TODO: CHANGE ME FROM BLUE TO THE RIGHT SETTING FOR GREEN!!!
    IOMUX->SECCFG.PINCM[(IOMUX_PINCM50)] = (IOMUX_PINCM_PC_CONNECTED | ((uint32_t) 0x00000001));
    /* --------- */


    GPIOB->DOUTCLR31_0 = PIN;
    GPIOB->DOESET31_0 = PIN;

    delay_cycles(POWER_STARTUP_DELAY); // delay to enable GPIO to turn on and reset
}

/* ---------- TODO! ---------- */

// TODO: Think about what states are in your state machine logic!
enum morse_state {
    DOT_TRANSMISSION,
    INTERELEM_TRANSMISSION,
};

// TODO: Complete this function using the states that you came up with
// Notice that we pass the message index and morse-code-state by reference.
//   this means that changes we make in the function will be made to the
//   variables that we've passed to it (and thus be persistent!).
uint32_t get_next_value(int *msg_index, enum morse_state *state) {
    uint32_t next_value;

    switch (*state) {
    case DOT_TRANSMISSION:
        *state = INTERELEM_TRANSMISSION; // next state
        next_value = 0x0u; // next value is an LED OFF
        break;

    case INTERELEM_TRANSMISSION:
        *state = DOT_TRANSMISSION;
        next_value = PIN;
        break;
    }

    return next_value;
}

/* --------------------------- */



int main(void)
{

    int msg_index = 0;
    enum morse_state state;
    uint32_t next_gpio_value = PIN;

    InitializeSleepIsStandby();

    InitializeProcessor();
    InitializeGPIO();
    InitializeTimerG0();

    NVIC_EnableIRQ(TIMG0_INT_IRQn); // Enable the timer interrupt

    /* - TODO! - */
    // TODO: Initialize state machine logic here based on message data
    state = DOT_TRANSMISSION;
    next_gpio_value = PIN;    // We will start with this value to GPIO
    /* --------- */

    TIMG0->COUNTERREGS.LOAD = DELAY; // This will load as soon as timer is enabled
    TIMG0->COUNTERREGS.CTRCTL |= (GPTIMER_CTRCTL_EN_ENABLED);

    #pragma nounroll
    while (1) {
        GPIOB->DOUT31_0 = next_gpio_value;
        next_gpio_value = get_next_value(&msg_index, &state); // Inter-character space
        __WFI(); // Go to sleep until timer counts down again.
    }
}


void TIMG0_IRQHandler(void)
{
    // This wakes up the processor!

    switch (TIMG0->CPU_INT.IIDX) {
        case GPTIMER_CPU_INT_IIDX_STAT_Z: // Counted down to zero event.
            // If we wanted to execute code in the ISR, it would go here.
            break;
        default:
            break;
    }
}

/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
