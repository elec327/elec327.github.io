
#include <ti/devices/msp/msp.h>

#include "lab6_helper.h"

uint16_t onTxPacket[] =  {0x0, 0x0, 0xE5F0, 0x1010, 0xE510, 0x10F0, 0xE510, 0xF010, 0xE510, 0x0010, 0xFFFF, 0xFFFF};

uint16_t offTxPacket[] = {0x0, 0x0, 0xE000, 0x0000, 0xE000, 0x0000, 0xE000, 0x0000, 0xE000, 0x0000, 0xFFFF, 0xFFFF};

uint16_t *txPacket;

int transmissionComplete = 0; // flag for SPI ISR wakeup
int timerTicked = 0; // flag for timer ISR wakeup
int idx = 0;

int message_len = sizeof(onTxPacket) / sizeof(onTxPacket[0]);


enum current_state_enum {
    LIGHTS_OFF = 0,
    LIGHTS_ON = 1
};


int main(void)
{
    InitializeProcessor();
    InitializeGPIO();
    InitializeSPI();

    InitializeTimerG0();
    InitializeTimerA1_PWM();

    // let the buzzer run for 0.1 s just so we know it's there!
    delay_cycles(1600000);
    TIMA1->COUNTERREGS.CTRCTL &= ~(GPTIMER_CTRCTL_EN_ENABLED); // Disable the buzzer

    NVIC_EnableIRQ(TIMG0_INT_IRQn); // Enable the timer interrupt

    TIMG0->COUNTERREGS.LOAD = 16383; // Set timer to N-1 for a half second
    TIMG0->COUNTERREGS.CTRCTL |= (GPTIMER_CTRCTL_EN_ENABLED);

    enum current_state_enum next_state;

    next_state = LIGHTS_ON;

    while (1) { // this loop will execute once per timer interrupt, currently 500 ms
        switch (next_state) {
        case LIGHTS_ON:
            txPacket = onTxPacket; // Set what SPI message will be transmitted. (all LEDs on)
            // Check state of buttons and decide next state
            if ( (GPIOA->DIN31_0 & (SW1 | SW2 | SW3 | SW4)) == (SW1 | SW2 | SW3 | SW4) )
                next_state = LIGHTS_ON; // If none of the buttons are pushed, stay with the lights on
            else
                next_state = LIGHTS_OFF;
            break;


        case LIGHTS_OFF:
        default:
            txPacket = offTxPacket; // Set what SPI message will be transmitted. (all LEDs off)
            next_state = LIGHTS_ON;
            break;
        }

        // Clear pending SPI interrupts
        NVIC_ClearPendingIRQ(SPI0_INT_IRQn);
        NVIC_EnableIRQ(SPI0_INT_IRQn);
        transmissionComplete = 0; // reset flag
        idx = 1; // reset pointer to point at the second element of the SPI message
        SPI0->TXDATA = *txPacket; // This will start TX ISR running.
        // It will stop itself at the end of the message, and disable SPI interrupts.



        while (!timerTicked) // Wait for timer wake up
            __WFI();

        timerTicked = 0; // reset timer interupt flag
    }
}

void SPI0_IRQHandler(void)
{
    switch (SPI0->CPU_INT.IIDX) {
        case SPI_CPU_INT_IIDX_STAT_TX_EVT: // SPI interrupt index for transmit FIFO
            SPI0->TXDATA = txPacket[idx];
            idx++;
            if (idx == message_len) {
               transmissionComplete = 1; 
               NVIC_DisableIRQ(SPI0_INT_IRQn);
            }
            break;
        default:
            break;
    }
}


void TIMG0_IRQHandler(void)
{
    // This wakes up the processor!

    switch (TIMG0->CPU_INT.IIDX) {
        case GPTIMER_CPU_INT_IIDX_STAT_Z: // Counted down to zero event.
            timerTicked = 1; // set a flag so we can know what woke us up.
            break;
        default:
            break;
    }
}

/*
 * Copyright (c) 2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
