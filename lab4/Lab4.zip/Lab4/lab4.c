/*
 * This template file
 */

#include <lab4_helper.h>
#include <ti/devices/msp/msp.h>
#include <string.h>


/* This results in approximately 0.5s of delay assuming 32.768 kHz CPU_CLK */
#define DELAY (3276) // N+1 is period

// Blue LED
#define BLUE   (0x1u << 22)
#define RED    (0x1u << 26)
#define GREEN  (0x1u << 27)


void InitializeGPIO(void) {
    GPIOB->GPRCM.RSTCTL = (GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETSTKYCLR_CLR | GPIO_RSTCTL_RESETASSERT_ASSERT);
    GPIOB->GPRCM.PWREN = (GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE);

    delay_cycles(POWER_STARTUP_DELAY); // delay to enable GPIO to turn on and reset

    IOMUX->SECCFG.PINCM[(IOMUX_PINCM50)] = IOMUX_PINCM_PC_CONNECTED | IOMUX_PINCM50_PF_TIMG8_CCP1; // Use as GPIO to make life easy TIMG8_C1
    IOMUX->SECCFG.PINCM[(IOMUX_PINCM57)] = IOMUX_PINCM_PC_CONNECTED | IOMUX_PINCM57_PF_TIMA1_CCP0; // These are both available on TIMA1[6]
    IOMUX->SECCFG.PINCM[(IOMUX_PINCM58)] = IOMUX_PINCM_PC_CONNECTED | IOMUX_PINCM58_PF_TIMA1_CCP1; // These are both available on TIMA1[6]


    GPIOB->DOUTCLR31_0 = BLUE; // start with blue on
    GPIOB->DOESET31_0 = BLUE | RED | GREEN;

    delay_cycles(POWER_STARTUP_DELAY); // delay to enable GPIO to turn on and reset
}


typedef struct _rgb {
    uint32_t red;
    uint32_t green;
    uint32_t blue;
} rgb;

// Do something interesting with colors...
rgb get_next_value() {
    static rgb current_value = {.red = 0, .green = 1000, .blue = 0};

    current_value.red += 100;
    if (current_value.red > 1599)
        current_value.red = 0;

    current_value.red = 100;

    current_value.green += 50;
    if (current_value.green > 1599)
        current_value.green = 0;

    current_value.blue += 100;
    if (current_value.blue > 1599)
        current_value.blue = 0;

    return current_value;
}


int main(void)
{

    int msg_index = 0;
    rgb next_value;

//    InitializeSleepIsStandby(); // Timers won't work in standby!

    InitializeProcessor();
    InitializeGPIO();
    InitializeTimerG0();
    InitializeTimerA1_G8_PWM();

    NVIC_EnableIRQ(TIMG0_INT_IRQn); // Enable the timer interrupt


    TIMG0->COUNTERREGS.LOAD = DELAY; // This will load as soon as timer is enabled
    TIMG0->COUNTERREGS.CTRCTL |= (GPTIMER_CTRCTL_EN_ENABLED);

    #pragma nounroll
    while (1) {
//        GPIOB->DOUT31_0 = next_gpio_value;
        next_value = get_next_value();
        TIMG8->COUNTERREGS.CC_01[1] = next_value.blue;
        TIMA1->COUNTERREGS.CC_01[0] = next_value.red;
        TIMA1->COUNTERREGS.CC_01[1] = next_value.green;

        __WFI(); // Go to sleep until timer counts down again.
    }
}


void TIMG0_IRQHandler(void)
{
    // This wakes up the processor!

    switch (TIMG0->CPU_INT.IIDX) {
        case GPTIMER_CPU_INT_IIDX_STAT_Z: // Counted down to zero event.
            // If we wanted to execute code in the ISR, it would go here.
            break;
        default:
            break;
    }
}

/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
